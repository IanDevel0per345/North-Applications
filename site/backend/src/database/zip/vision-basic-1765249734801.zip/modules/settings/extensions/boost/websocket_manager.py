import asyncio
import json
import socketio
import logging
import aiohttp
from typing import Dict, Any, Optional
import hashlib
import uuid

class BoostWebSocketManager:
    def __init__(self, server_url: str = "http://localhost:8081", reconnect_interval: int = 5):
        self.server_url = server_url
        self.reconnect_interval = reconnect_interval
        self.sio = None
        self.connected = False
        self.connecting = False
        self.should_reconnect = True
        
        # Configurar logger
        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(logging.INFO)
        if not self.logger.handlers:
            handler = logging.StreamHandler()
            handler.setFormatter(logging.Formatter('[%(name)s] %(message)s'))
            self.logger.addHandler(handler)
        
        self.api_key = None
        self.bot = None
        
        # Sistema de respostas pendentes
        self.pending_responses = {}
        
        # Task de reconexão
        self.reconnect_task = None
        self.reconnect_attempts = 0

    def set_bot(self, bot):
        """Define a instância do bot"""
        self.bot = bot
        
        # Gerar API key única baseada no bot
        if bot and hasattr(bot, 'user') and bot.user:
            bot_id = str(bot.user.id)
            # Gerar API key única e persistente
            self.api_key = self._generate_api_key(bot_id)
            self.logger.info(f"API Key gerada para Boost: {self.api_key[:8]}...")

    def _generate_api_key(self, bot_id: str) -> str:
        """Gera uma API key única e persistente para o bot"""
        # Usar hash do bot_id + um salt fixo para gerar key consistente
        salt = "vision_boost_api_2024"
        unique_string = f"{bot_id}_{salt}"
        api_key = hashlib.sha256(unique_string.encode()).hexdigest()
        return api_key

    async def start(self):
        """Inicia o gerenciador Socket.IO"""
        self.should_reconnect = True
        await self._connect()

    async def stop(self):
        """Para o gerenciador Socket.IO"""
        self.should_reconnect = False
        
        if self.sio:
            await self.sio.disconnect()
            self.sio = None
        
        self.connected = False

    async def _connect(self):
        """Conecta ao servidor Socket.IO"""
        if self.connecting or self.connected:
            self.logger.info("Já conectando ou conectado, ignorando nova tentativa")
            return
        
        self.connecting = True
        
        try:
            # Health-check: evitar erros ruidosos quando o servidor não está rodando
            next_interval = min(self.reconnect_interval * 2, 60)
            if not await self._probe_server():
                self.connecting = False
                self.connected = False
                self.logger.warning(
                    f"Servidor Boost WebSocket indisponível. Nova tentativa em {next_interval}s"
                )
                if self.should_reconnect:
                    self.reconnect_interval = next_interval
                    await self._schedule_reconnect()
                return

            self.logger.info(f"🔄 Conectando ao Boost WebSocket: {self.server_url}")
            
            # Criar cliente Socket.IO
            self.sio = socketio.AsyncClient(
                reconnection=False,
                logger=False,
                engineio_logger=False
            )
            
            self.logger.info("✓ Cliente Socket.IO criado")
            
            # Configurar eventos ANTES de conectar
            self._setup_events()
            self.logger.info("✓ Eventos configurados")
            
            # Conectar com timeout
            self.logger.info(f"⏳ Tentando conectar (timeout: 15s)...")
            await asyncio.wait_for(
                self.sio.connect(self.server_url, wait_timeout=10),
                timeout=15
            )
            
            self.connected = True
            self.connecting = False
            
            self.logger.info("✅ Conectado ao Boost WebSocket com sucesso!")
                    
        except asyncio.TimeoutError:
            self.connecting = False
            self.connected = False
            self.logger.error(f"❌ Timeout ao conectar ao Boost WebSocket (15s)")
            if self.should_reconnect:
                await self._schedule_reconnect()

    async def _probe_server(self, timeout: float = 3.0) -> bool:
        """Verifica rapidamente se o servidor está aceitando conexões HTTP."""
        try:
            url = self.server_url.rstrip('/')
            # Tenta acessar a raiz; se falhar, provavelmente o servidor está offline
            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=timeout) as resp:
                    # Considera disponível para qualquer status de resposta
                    return True
        except Exception:
            return False

    def _setup_events(self):
        """Configura eventos do Socket.IO"""
        if not self.sio:
            return
        
        @self.sio.event
        async def connect():
            self.logger.info("Conectado ao servidor Boost WebSocket")
            self.connected = True
            
            # Aguardar um pouco para garantir que a conexão está estável
            await asyncio.sleep(1.5)
            
            # Enviar informações do bot para a API
            if self.bot and self.api_key:
                try:
                    bot_id = str(self.bot.user.id) if self.bot.user else None
                    
                    # Carregar config.json para obter unique_id
                    try:
                        with open('config.json', 'r', encoding='utf-8') as f:
                            config = json.load(f)
                            unique_id = config.get("botID", "VisionBot")
                    except Exception:
                        unique_id = "VisionBot"
                    
                    registration_data = {
                        'bot_id': bot_id,
                        'unique_id': unique_id,
                        'api_key': self.api_key
                    }
                    
                    if self.sio and self.connected:
                        await self.sio.emit('bot_connected', registration_data)
                        self.logger.info(f"Bot registrado no Boost WebSocket - API Key: {self.api_key[:8]}...")
                        
                except Exception as e:
                    self.logger.error(f"Erro ao enviar bot_connected: {e}")
        
        @self.sio.event
        async def disconnect():
            self.logger.info("Desconectado do servidor Boost WebSocket")
            self.connected = False
            
            # Tentar reconectar se necessário
            if self.should_reconnect:
                await self._schedule_reconnect()
        
        @self.sio.event
        async def connect_error(data):
            # Aviso conciso; erros detalhados são suprimidos
            self.logger.warning(f"Conexão ao Boost WebSocket falhou: {data}")
            self.connected = False
        
        # Eventos de resposta específicos
        @self.sio.on('create_gift_response')
        async def on_create_gift_response(data):
            self.logger.debug(f"Resposta de criação de gift recebida: {data}")
            if 'create_gift_response' in self.pending_responses:
                future = self.pending_responses.pop('create_gift_response')
                if not future.done():
                    future.set_result(data)
        
        @self.sio.on('get_gifts_response')
        async def on_get_gifts_response(data):
            self.logger.debug(f"Resposta de listagem de gifts recebida: {data}")
            if 'get_gifts_response' in self.pending_responses:
                future = self.pending_responses.pop('get_gifts_response')
                if not future.done():
                    future.set_result(data)
        
        @self.sio.on('update_gift_response')
        async def on_update_gift_response(data):
            self.logger.debug(f"Resposta de atualização de gift recebida: {data}")
            if 'update_gift_response' in self.pending_responses:
                future = self.pending_responses.pop('update_gift_response')
                if not future.done():
                    future.set_result(data)
        
        @self.sio.on('delete_gift_response')
        async def on_delete_gift_response(data):
            self.logger.debug(f"Resposta de deleção de gift recebida: {data}")
            if 'delete_gift_response' in self.pending_responses:
                future = self.pending_responses.pop('delete_gift_response')
                if not future.done():
                    future.set_result(data)

        @self.sio.on('delete_all_gifts_response')
        async def on_delete_all_gifts_response(data):
            self.logger.debug(f"Resposta de deleção em massa de gifts recebida: {data}")
            if 'delete_all_gifts_response' in self.pending_responses:
                future = self.pending_responses.pop('delete_all_gifts_response')
                if not future.done():
                    future.set_result(data)

    async def _schedule_reconnect(self):
        """Agenda reconexão"""
        if self.reconnect_task and not self.reconnect_task.done():
            return
        
        self.reconnect_task = asyncio.create_task(self._reconnect())

    async def _reconnect(self):
        """Reconecta ao WebSocket com backoff exponencial"""
        if not self.should_reconnect:
            return
        
        # Backoff exponencial: 5s, 10s, 20s, 40s, 60s (max)
        max_interval = 60
        current_interval = min(self.reconnect_interval * 2, max_interval)
        
        self.reconnect_attempts += 1
        self.logger.info(f"🔄 Reconexão Boost WS em {current_interval}s (tentativa {self.reconnect_attempts})")
        await asyncio.sleep(current_interval)
        
        if self.should_reconnect:
            self.reconnect_interval = current_interval
            await self._connect()

    async def send_message(self, event: str, data: Dict[str, Any]) -> bool:
        """Envia mensagem via Socket.IO"""
        if not self.connected or not self.sio:
            self.logger.warning("⚠️ Boost WebSocket não conectado, não é possível enviar mensagem")
            return False
        
        try:
            await self.sio.emit(event, data)
            self.logger.debug(f"Mensagem enviada: {event}")
            return True
            
        except Exception as e:
            self.logger.error(f"Erro ao enviar mensagem: {e}")
            self.connected = False
            if self.should_reconnect:
                await self._schedule_reconnect()
            return False

    async def create_gift(self, gift_data: Dict[str, Any]) -> Dict[str, Any]:
        """Cria um novo gift"""
        if not self.api_key:
            return {
                "success": False,
                "message": "API key não configurada"
            }
        
        data = {
            "api_key": self.api_key,
            "gift_data": gift_data
        }
        
        if not await self.send_message("create_gift", data):
            return {
                "success": False,
                "message": "Não foi possível enviar mensagem de criação de gift"
            }
        
        return await self._wait_for_response("create_gift_response", timeout=10.0)

    async def get_gifts(self) -> Dict[str, Any]:
        """Obtém lista de gifts"""
        if not self.api_key:
            return {
                "success": False,
                "message": "API key não configurada"
            }
        
        data = {
            "api_key": self.api_key
        }
        
        if not await self.send_message("get_gifts", data):
            return {
                "success": False,
                "message": "Não foi possível enviar solicitação de listagem de gifts"
            }
        
        return await self._wait_for_response("get_gifts_response", timeout=10.0)

    async def update_gift(self, gift_id: str, gift_data: Dict[str, Any]) -> Dict[str, Any]:
        """Atualiza um gift existente"""
        if not self.api_key:
            return {
                "success": False,
                "message": "API key não configurada"
            }
        
        data = {
            "api_key": self.api_key,
            "gift_id": gift_id,
            "gift_data": gift_data
        }
        
        if not await self.send_message("update_gift", data):
            return {
                "success": False,
                "message": "Não foi possível enviar solicitação de atualização de gift"
            }
        
        return await self._wait_for_response("update_gift_response", timeout=10.0)

    async def delete_gift(self, gift_id: str) -> Dict[str, Any]:
        """Deleta um gift"""
        if not self.api_key:
            return {
                "success": False,
                "message": "API key não configurada"
            }
        
        data = {
            "api_key": self.api_key,
            "gift_id": gift_id
        }
        
        if not await self.send_message("delete_gift", data):
            return {
                "success": False,
                "message": "Não foi possível enviar solicitação de deleção de gift"
            }
        
        return await self._wait_for_response("delete_gift_response", timeout=10.0)

    async def delete_all_gifts(self) -> Dict[str, Any]:
        """Deleta todos os gifts"""
        if not self.api_key:
            return {
                "success": False,
                "message": "API key não configurada"
            }
        
        data = {
            "api_key": self.api_key
        }
        
        if not await self.send_message("delete_all_gifts", data):
            return {
                "success": False,
                "message": "Não foi possível enviar solicitação de deleção em massa de gifts"
            }
        
        return await self._wait_for_response("delete_all_gifts_response", timeout=10.0)

    async def _wait_for_response(self, request_id: str, timeout: float = 10.0) -> Dict[str, Any]:
        """Aguarda resposta específica do servidor"""
        try:
            # Criar future para aguardar resposta
            future = asyncio.Future()
            self.pending_responses[request_id] = future
            
            self.logger.info(f"Aguardando evento '{request_id}' com timeout de {timeout}s")
            
            # Aguardar resposta com timeout
            response = await asyncio.wait_for(future, timeout=timeout)
            
            self.logger.info(f"Resposta recebida para '{request_id}': {response}")
            
            return response
            
        except asyncio.TimeoutError:
            # Remover future pendente se timeout
            self.pending_responses.pop(request_id, None)
            return {
                "success": False,
                "message": f"Timeout ao aguardar resposta para {request_id}"
            }
        except Exception as e:
            # Remover future pendente em caso de erro
            self.pending_responses.pop(request_id, None)
            return {
                "success": False,
                "message": str(e)
            }

    def is_connected(self) -> bool:
        """Verifica se está conectado"""
        return self.connected

    def get_connection_info(self) -> Dict[str, Any]:
        """Obtém informações da conexão"""
        return {
            "connected": self.connected,
            "server_url": self.server_url,
            "api_key": self.api_key[:8] + "..." if self.api_key else None
        }


# Instância global do gerenciador
_boost_ws_manager = None

def get_websocket_manager() -> BoostWebSocketManager:
    """Obtém a instância global do gerenciador de WebSocket do Boost"""
    global _boost_ws_manager
    if _boost_ws_manager is None:
        _boost_ws_manager = BoostWebSocketManager()
    return _boost_ws_manager
