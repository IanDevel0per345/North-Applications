import asyncio
import json
import socketio
import logging
from typing import Dict, Any, Optional, Callable
from datetime import datetime
import uuid

class WebSocketManager:
    def __init__(self, server_url: str = "https://cloud.visionapplications.com.br", reconnect_interval: int = 5):
        self.server_url = server_url
        self.reconnect_interval = reconnect_interval
        self.sio = None
        self.connected = False
        self.connecting = False
        self.should_reconnect = True
        self.logger = logging.getLogger(__name__)
        
        # Lock para prevenir conexões simultâneas
        self._connect_lock = asyncio.Lock()
        self._last_connect_time = 0
        self._min_connect_interval = 3  # Mínimo de 3 segundos entre tentativas
        
        # Callbacks para eventos
        self.on_connect_callback: Optional[Callable] = None
        self.on_disconnect_callback: Optional[Callable] = None
        self.on_message_callback: Optional[Callable] = None
        self.on_error_callback: Optional[Callable] = None
        
        # Sistema de respostas pendentes
        self.pending_responses = {}
        
        # Task de reconexão
        self.reconnect_task = None
        self.reconnect_loop_task = None
        self.connection_monitor_task = None
        self.reconnect_attempts = 0
        self._last_disconnect_time = 0
        self._last_connect_event_time = 0
        self._last_connect_error_time = 0
        self._processing_disconnect = False  # Flag para prevenir processamento simultâneo de disconnect
        self._connection_start_time = 0  # Timestamp do início da conexão
        
        # Sistema de heartbeat (ping/pong customizado)
        self.heartbeat_task = None
        self.heartbeat_interval = 20  # Enviar ping a cada 20 segundos
        self.heartbeat_timeout = 90  # Timeout de 90 segundos sem resposta (reduzido para detectar problemas mais rápido)
        self._last_pong_time = 0  # Timestamp do último pong recebido
        self._pending_ping = False  # Flag para indicar se há um ping pendente
        self._heartbeat_enabled = True  # Flag para habilitar/desabilitar heartbeat
        
        # Queue para processamento não bloqueante de eventos
        self._event_queue = asyncio.Queue(maxsize=100)
        self._event_processor_task = None

    def set_callbacks(self, on_connect: Callable = None, on_disconnect: Callable = None, 
                     on_message: Callable = None, on_error: Callable = None):
        """Define callbacks para eventos do WebSocket"""
        self.on_connect_callback = on_connect
        self.on_disconnect_callback = on_disconnect
        self.on_message_callback = on_message
        self.on_error_callback = on_error
    
    async def _safe_disconnect(self):
        """Desconecta de forma segura, ignorando erros de conexão já fechada"""
        if not self.sio:
            return
        
        try:
            await self.sio.disconnect()
        except (ConnectionResetError, OSError, ConnectionError, 
                socketio.exceptions.ConnectionError, asyncio.CancelledError) as e:
            # Erros esperados quando a conexão já foi fechada pelo host remoto
            # Não logar como erro, apenas debug
            self.logger.debug(f"Desconexão segura: {type(e).__name__} - conexão já estava fechada")
        except Exception as e:
            # Outros erros inesperados - logar mas não propagar
            self.logger.debug(f"Erro ao desconectar (não crítico): {type(e).__name__}: {e}")
        finally:
            # Sempre limpar referência após tentar desconectar
            self.sio = None

    def set_bot(self, bot):
        """Define a instância do bot e o bot_id para uso global"""
        from functions.database import database as db
        import json
        self.bot = bot
        if bot:
            # Carregar config.json para obter botID e server
            try:
                with open('config.json', 'r', encoding='utf-8') as f:
                    config = json.load(f)
                    self.bot_unique_id = config.get("botID", "VisionBot")  # ID único do bot
                    self.bot_server_id = config.get("bot", {}).get("server")  # Servidor principal
                    
                    # Verificar se bot.user está disponível
                    if hasattr(bot, 'user') and bot.user and hasattr(bot.user, 'id'):
                        self.bot_discord_id = str(bot.user.id)  # ID do Discord do bot
                    else:
                        # Se bot.user não estiver pronto, usar o ID do config
                        self.bot_discord_id = config.get("bot", {}).get("id")
                    
                    self.logger.info(f"Bot configurado - UniqueID: {self.bot_unique_id}, Server: {self.bot_server_id}, DiscordID: {self.bot_discord_id}")
            except Exception as e:
                self.logger.error(f"Erro ao carregar config.json: {e}")
                import traceback
                traceback.print_exc()
                self.bot_unique_id = "VisionBot"
                self.bot_server_id = None
                self.bot_discord_id = None
            
            # Ainda pegar o client_id do cloud_data para OAuth
            cloud_config = db.get_document("cloud_data") or {}
            self.oauth_client_id = cloud_config.get("client_id")
            self.logger.info(f"OAuth Client ID: {self.oauth_client_id}")
        else:
            self.bot_unique_id = None
            self.bot_server_id = None
            self.bot_discord_id = None
            self.oauth_client_id = None

    def get_bot_registration_id(self):
        """Obtém o ID do bot que está fazendo o registro"""
        try:
            # Retornar o ID do Discord do bot principal
            if hasattr(self, 'bot_discord_id') and self.bot_discord_id:
                return self.bot_discord_id
            elif hasattr(self, 'bot') and self.bot and hasattr(self.bot, 'user') and self.bot.user:
                if hasattr(self.bot.user, 'id'):
                    return str(self.bot.user.id)
            return None
        except Exception as e:
            self.logger.error(f"Erro ao obter ID do bot: {e}")
            return None

    async def start(self):
        """Inicia o gerenciador Socket.IO"""
        # Configurar exception handler global para capturar erros de callbacks do asyncio
        # relacionados a conexões já fechadas
        def _asyncio_exception_handler(loop, context):
            """Handler para exceções do asyncio que não são críticas"""
            exception = context.get('exception')
            if exception:
                # Capturar erros de conexão resetada em callbacks do asyncio
                if isinstance(exception, (ConnectionResetError, OSError, ConnectionError)):
                    # Erro esperado quando conexão já foi fechada pelo host remoto
                    # Não logar como erro crítico, apenas debug
                    self.logger.debug(f"Erro de conexão em callback do asyncio (não crítico): {type(exception).__name__}")
                    return
            
            # Para outros erros ou quando não há exceção, usar handler padrão do asyncio
            # O handler padrão imprime no stderr, mas podemos suprimir erros específicos
            message = context.get('message', '')
            if 'connection_lost' in message.lower() or '_call_connection_lost' in message:
                # Suprimir erros de connection_lost que são esperados
                self.logger.debug(f"Callback de conexão perdida (não crítico): {message}")
                return
            
            # Para outros erros, logar normalmente
            if exception:
                self.logger.warning(f"Exceção não tratada no asyncio: {type(exception).__name__}: {exception}")
            else:
                self.logger.warning(f"Erro no asyncio: {message}")
        
        # Configurar o exception handler apenas se ainda não foi configurado
        try:
            loop = asyncio.get_event_loop()
            if not hasattr(loop, '_websocket_exception_handler_set'):
                # Salvar handler anterior se existir
                old_handler = loop.get_exception_handler()
                def _combined_handler(loop, context):
                    # Primeiro tentar nosso handler
                    _asyncio_exception_handler(loop, context)
                    # Se havia handler anterior, chamá-lo também
                    if old_handler:
                        old_handler(loop, context)
                
                loop.set_exception_handler(_combined_handler)
                loop._websocket_exception_handler_set = True
        except Exception:
            # Se não conseguir configurar, continuar normalmente
            pass
        
        # Verificar se já está iniciado
        if self.reconnect_loop_task and not self.reconnect_loop_task.done():
            self.logger.warning("⚠️ WebSocket já está iniciado, pulando inicialização duplicada")
            return
        
        self.should_reconnect = True
        self.reconnect_attempts = 0
        
        # Iniciar processador de eventos não bloqueante
        if self._event_processor_task is None or self._event_processor_task.done():
            self._event_processor_task = asyncio.create_task(self._process_event_queue())
            self.logger.info("📨 Processador de eventos iniciado")
        
        # Iniciar loop de reconexão contínuo
        if self.reconnect_loop_task is None or self.reconnect_loop_task.done():
            self.reconnect_loop_task = asyncio.create_task(self._reconnect_loop())
            self.logger.info("🔄 Loop de reconexão contínuo iniciado")
        
        # Iniciar monitor de conexão
        if self.connection_monitor_task is None or self.connection_monitor_task.done():
            self.connection_monitor_task = asyncio.create_task(self._connection_monitor())
            self.logger.info("👁️ Monitor de conexão iniciado")
        
        # Aguardar um pouco antes de tentar conectar para evitar conexões muito rápidas
        await asyncio.sleep(2)
        
        # Tentar conectar (o loop de reconexão vai cuidar disso também)
        if not self.connected and not self.connecting:
            await self._connect()

    async def stop(self):
        """Para o gerenciador Socket.IO"""
        self.should_reconnect = False
        
        # Cancelar processador de eventos
        if self._event_processor_task and not self._event_processor_task.done():
            self._event_processor_task.cancel()
            try:
                await self._event_processor_task
            except asyncio.CancelledError:
                pass
        
        # Cancelar tasks de reconexão e monitoramento
        if self.reconnect_loop_task and not self.reconnect_loop_task.done():
            self.reconnect_loop_task.cancel()
            try:
                await self.reconnect_loop_task
            except asyncio.CancelledError:
                pass
        
        if self.connection_monitor_task and not self.connection_monitor_task.done():
            self.connection_monitor_task.cancel()
            try:
                await self.connection_monitor_task
            except asyncio.CancelledError:
                pass
        
        if self.reconnect_task and not self.reconnect_task.done():
            self.reconnect_task.cancel()
            try:
                await self.reconnect_task
            except asyncio.CancelledError:
                pass
        
        # Parar heartbeat
        if self.heartbeat_task and not self.heartbeat_task.done():
            self.heartbeat_task.cancel()
            try:
                await self.heartbeat_task
            except asyncio.CancelledError:
                pass
            self.heartbeat_task = None
        
        if self.sio:
            await self._safe_disconnect()
        
        self.connected = False
        self.connecting = False

    async def _connect(self):
        """Conecta ao servidor Socket.IO com proteção contra conexões simultâneas"""
        import time
        
        # Verificar se já está conectado e estável
        if self.connected and self.sio:
            try:
                # Verificar se o socket está realmente conectado
                if hasattr(self.sio, 'connected') and self.sio.connected:
                    return  # Já conectado e estável
            except Exception:
                pass  # Se houver erro ao verificar, continuar com reconexão
        
        # Usar lock para prevenir conexões simultâneas
        async with self._connect_lock:
            # Verificar novamente após adquirir o lock
            if self.connected and self.sio:
                try:
                    if hasattr(self.sio, 'connected') and self.sio.connected:
                        return
                except Exception:
                    pass
            
            # Verificar intervalo mínimo entre tentativas
            current_time = time.time()
            time_since_last_attempt = current_time - self._last_connect_time
            if time_since_last_attempt < self._min_connect_interval:
                wait_time = self._min_connect_interval - time_since_last_attempt
                self.logger.debug(f"⏳ Aguardando {wait_time:.1f}s antes de tentar conectar novamente...")
                await asyncio.sleep(wait_time)
            
            # Verificar se já está conectando (após esperar)
            if self.connecting:
                self.logger.debug("⏳ Conexão já em andamento, aguardando...")
                return
            
            self.connecting = True
            self._last_connect_time = time.time()
            
            try:
                # Limpar conexão anterior se existir
                if self.sio:
                    await self._safe_disconnect()
                
                self.reconnect_attempts += 1
                self.logger.info(f"🔄 Tentativa de conexão #{self.reconnect_attempts} ao Socket.IO: {self.server_url}")
                
                # Criar cliente Socket.IO com configurações adequadas para máxima estabilidade
                # O cliente Socket.IO usa valores padrão compatíveis com o servidor
                # O servidor está configurado com pingTimeout: 300s e pingInterval: 60s
                self.sio = socketio.AsyncClient(
                    reconnection=False,  # Gerenciar reconexão manualmente
                    logger=False,
                    engineio_logger=False,
                    # Configurações de transporte para manter conexão ativa
                    request_timeout=120  # Timeout de requisição de 2 minutos
                    # WebSocket é o transporte padrão e será usado automaticamente
                )
                
                # Configurar eventos ANTES de conectar
                self._setup_events()
                
                # Conectar sem timeout - nunca desiste da conexão
                await self.sio.connect(self.server_url, wait_timeout=None)
                
                # O evento connect() será chamado automaticamente pelo socket.io
                # e atualizará o estado. Aqui apenas garantimos que o estado está correto
                # após a conexão bem-sucedida
                if hasattr(self.sio, 'connected') and self.sio.connected:
                    self.connected = True
                    self.connecting = False
                    self.reconnect_attempts = 0  # Resetar contador ao conectar com sucesso
                    self._connection_start_time = time.time()  # Registrar quando conectou
                    self._last_pong_time = time.time()  # Resetar timestamp do último pong
                    self._pending_ping = False  # Resetar flag de ping pendente
                    
                    self.logger.info("✅ Conectado ao Socket.IO com sucesso!")
                    
                    # Iniciar sistema de heartbeat
                    if self._heartbeat_enabled:
                        self._start_heartbeat()
                    
                    # Callback de conexão
                    if self.on_connect_callback:
                        try:
                            await self.on_connect_callback()
                        except Exception as e:
                            self.logger.error(f"Erro no callback de conexão: {e}")
                else:
                    # Se conectou mas o estado não está correto, aguardar um pouco
                    # O evento connect() deve ser chamado em breve
                    self.logger.debug("Aguardando evento connect() para confirmar conexão...")
                    await asyncio.sleep(1)
                        
            except socketio.exceptions.ConnectionError as e:
                self.connecting = False
                self.connected = False
                self.logger.error(f"❌ Erro de conexão Socket.IO (tentativa #{self.reconnect_attempts}): {e}")
                # Limpar socket antigo completamente
                if self.sio:
                    try:
                        await self._safe_disconnect()
                    except Exception:
                        pass
                    self.sio = None  # Limpar referência
                # Resetar timestamps para permitir nova tentativa
                self._connection_start_time = 0
                self._last_pong_time = 0
                self._pending_ping = False
                if self.on_error_callback:
                    try:
                        await self.on_error_callback(e)
                    except Exception:
                        pass
                # O loop de reconexão continuará tentando automaticamente
            except Exception as e:
                self.connecting = False
                self.connected = False
                self.logger.error(f"❌ Erro ao conectar ao Socket.IO (tentativa #{self.reconnect_attempts}): {e}")
                import traceback
                traceback.print_exc()
                
                # Limpar socket antigo completamente
                if self.sio:
                    try:
                        await self._safe_disconnect()
                    except Exception:
                        pass
                    self.sio = None  # Limpar referência
                # Resetar timestamps para permitir nova tentativa
                self._connection_start_time = 0
                self._last_pong_time = 0
                self._pending_ping = False
                
                if self.on_error_callback:
                    try:
                        await self.on_error_callback(e)
                    except Exception as callback_error:
                        self.logger.error(f"Erro no callback de erro: {callback_error}")
                # O loop de reconexão continuará tentando automaticamente
            finally:
                # Garantir que connecting seja False mesmo em caso de erro não capturado
                self.connecting = False

    def _setup_events(self):
        """Configura eventos do Socket.IO"""
        if not self.sio:
            return
        
        # NOTA: Não configurar handlers customizados de ping/pong
        # O Socket.IO gerencia heartbeat automaticamente via Engine.IO
        # Handlers customizados podem interferir com o sistema interno
        
        @self.sio.event
        async def connect():
            import time
            current_time = time.time()
            
            # Prevenir múltiplos eventos connect muito próximos (debounce de 3 segundos)
            if hasattr(self, '_last_connect_event_time'):
                if current_time - self._last_connect_event_time < 3:
                    self.logger.debug("⚠️ Evento connect ignorado (muito próximo do anterior)")
                    return
            
            self._last_connect_event_time = current_time
            self._connection_start_time = current_time  # Registrar timestamp da conexão
            self._last_pong_time = current_time  # Resetar timestamp do último pong
            self._pending_ping = False  # Resetar flag de ping pendente
            
            self.logger.info("✅ Conectado ao servidor Socket.IO")
            
            # Atualizar estado imediatamente quando receber evento connect
            self.connected = True
            self.connecting = False
            self.reconnect_attempts = 0  # Resetar contador ao conectar com sucesso
            
            # Atualizar oauth_client_id do banco de dados se não estiver definido
            if not self.oauth_client_id:
                from functions.database import database as db
                cloud_config = db.get_document("cloud_data") or {}
                self.oauth_client_id = cloud_config.get("client_id")
                if self.oauth_client_id:
                    self.logger.info(f"[CONNECT] OAuth Client ID carregado: {self.oauth_client_id}")
            
            # Iniciar sistema de heartbeat se ainda não estiver rodando
            if self._heartbeat_enabled and (not self.heartbeat_task or self.heartbeat_task.done()):
                self._start_heartbeat()
            
            # Aguardar um pouco para garantir que a conexão está estável antes de enviar dados
            await asyncio.sleep(1)
            
            # Enviar informações completas do bot para a API
            if hasattr(self, 'bot') and self.bot:
                try:
                    # Verificar se temos as informações necessárias
                    if not hasattr(self, 'bot_discord_id') or not self.bot_discord_id:
                        # Tentar várias vezes até conseguir
                        for attempt in range(5):
                            await asyncio.sleep(1)
                            
                            if hasattr(self, 'bot') and self.bot and hasattr(self.bot, 'user') and self.bot.user:
                                self.bot_discord_id = str(self.bot.user.id)
                                break
                        
                        # Se após 5 tentativas não conseguiu, desistir
                        if not hasattr(self, 'bot_discord_id') or not self.bot_discord_id:
                            self.logger.error("❌ Bot não está pronto. Aguarde o on_ready ou reinicie o bot.")
                            return
                    
                    # Obter lista de servidores de forma segura
                    guilds = []
                    try:
                        if hasattr(self.bot, 'guilds') and self.bot.guilds:
                            guilds = [str(g.id) for g in self.bot.guilds]
                    except Exception as e:
                        self.logger.error(f"Erro ao obter guilds: {e}")
                    
                    # Preparar dados completos para registro
                    registration_data = {
                        'bot_id': self.bot_discord_id,  # ID do Discord do bot principal
                        'unique_id': self.bot_unique_id,  # ID único do config.json (ex: VisionBot8)
                        'server_id': self.bot_server_id,  # Servidor principal do bot
                        'oauth_client_id': self.oauth_client_id,  # Client ID do OAuth se configurado
                        'guild_count': len(guilds),
                        'guilds': guilds  # Lista de servidores
                    }
                    
                    # Verificar se realmente está conectado antes de emitir
                    # Aguardar um pouco mais para garantir que o estado está estável
                    await asyncio.sleep(0.5)
                    
                    # Verificar novamente o estado antes de emitir
                    is_really_connected = False
                    if self.sio:
                        try:
                            if hasattr(self.sio, 'connected'):
                                is_really_connected = self.sio.connected
                            # Verificar também o estado do engine IO
                            if is_really_connected and hasattr(self.sio, 'eio'):
                                try:
                                    if hasattr(self.sio.eio, 'state') and self.sio.eio.state != 'connected':
                                        is_really_connected = False
                                except Exception:
                                    pass
                        except Exception:
                            is_really_connected = False
                    
                    if self.sio and self.connected and is_really_connected:
                        try:
                            await self.sio.emit('bot_connected', registration_data)
                            self.logger.info(f"✅ Bot registrado na API ({len(guilds)} servidor(es))")
                            
                            # Sincronizar definições se oauth_client_id estiver configurado
                            if self.oauth_client_id:
                                try:
                                    from functions.database import database as db
                                    cloud_config = db.get_document("cloud_data") or {}
                                    definitions = cloud_config.get("definitions", {})
                                    if definitions:
                                        await self.update_definitions(definitions)
                                        self.logger.info("[CONNECT] Definições sincronizadas com a API")
                                except Exception as def_error:
                                    self.logger.warning(f"[CONNECT] Erro ao sincronizar definições: {def_error}")
                        except Exception as emit_error:
                            self.logger.error(f"❌ Erro ao emitir bot_connected: {emit_error}")
                            # Se falhar ao emitir, pode ser que desconectou durante o processo
                            self.connected = False
                except Exception as e:
                    self.logger.error(f"Erro ao enviar bot_connected: {e}")
                    import traceback
                    traceback.print_exc()
            
            if self.on_connect_callback:
                try:
                    await self.on_connect_callback()
                except Exception as e:
                    self.logger.error(f"Erro no callback de conexão: {e}")
        
        @self.sio.event
        async def disconnect():
            import time
            current_time = time.time()
            
            # Prevenir processamento simultâneo de disconnect
            if self._processing_disconnect:
                self.logger.debug("⚠️ Evento disconnect já sendo processado, ignorando")
                return
            
            # Ignorar desconexões muito rápidas após conectar (menos de 30 segundos)
            # Isso evita desconexões falsas durante o handshake inicial e operações normais
            if self._connection_start_time > 0:
                time_since_connect = current_time - self._connection_start_time
                if time_since_connect < 30:  # Aumentado para 30 segundos para evitar falsos positivos
                    self.logger.debug(f"⚠️ Evento disconnect ignorado (muito próximo da conexão: {time_since_connect:.1f}s)")
                    return
            
            # Prevenir spam de eventos disconnect muito próximos (debounce de 10 segundos)
            if current_time - self._last_disconnect_time < 10:
                self.logger.debug(f"⚠️ Evento disconnect ignorado (muito próximo do anterior: {current_time - self._last_disconnect_time:.1f}s)")
                return
            
            # VERIFICAR SE REALMENTE DESCONECTOU antes de processar
            # Às vezes o evento disconnect é chamado mas o socket ainda está conectado
            if self.sio:
                try:
                    # Verificar se o socket está realmente desconectado
                    if hasattr(self.sio, 'connected') and self.sio.connected:
                        # Socket ainda está conectado - ignorar evento disconnect (falso positivo)
                        self.logger.debug("⚠️ Evento disconnect ignorado - socket ainda está conectado (falso positivo)")
                        return
                    
                    # Verificar também o estado do engine IO
                    if hasattr(self.sio, 'eio'):
                        try:
                            if hasattr(self.sio.eio, 'state'):
                                if self.sio.eio.state == 'connected':
                                    # Engine IO ainda está conectado - ignorar
                                    self.logger.debug("⚠️ Evento disconnect ignorado - engine IO ainda está conectado (falso positivo)")
                                    return
                        except Exception:
                            pass
                except Exception:
                    # Se houver erro ao verificar, continuar com processamento normal
                    pass
            
            # Marcar como processando
            self._processing_disconnect = True
            self._last_disconnect_time = current_time
            
            try:
                # Verificar novamente antes de atualizar estado (double-check)
                really_disconnected = True
                if self.sio:
                    try:
                        if hasattr(self.sio, 'connected'):
                            really_disconnected = not self.sio.connected
                    except Exception:
                        pass
                
                if really_disconnected:
                    # Realmente desconectou - atualizar estado
                    # Usar debug ao invés de warning para reduzir ruído nos logs
                    self.logger.debug("❌ Desconectado do servidor Socket.IO - O loop de reconexão tentará reconectar automaticamente")
                    self.logger.debug(f"📊 Informações da desconexão: connected={self.connected}, connecting={self.connecting}, reconnect_attempts={self.reconnect_attempts}")
                    
                    # Parar heartbeat ao desconectar
                    if self.heartbeat_task and not self.heartbeat_task.done():
                        self.heartbeat_task.cancel()
                        try:
                            await self.heartbeat_task
                        except asyncio.CancelledError:
                            pass
                        self.heartbeat_task = None
                    
                    # Atualizar estado imediatamente
                    self.connected = False
                    self.connecting = False
                    
                    # Resetar timestamp de conexão para permitir nova conexão limpa
                    self._connection_start_time = 0
                    self._last_pong_time = 0
                    self._pending_ping = False
                    
                    if self.on_disconnect_callback:
                        try:
                            await self.on_disconnect_callback()
                        except Exception as e:
                            self.logger.error(f"Erro no callback de desconexão: {e}")
                    
                    # RECONEXÃO IMEDIATA - não esperar o loop de reconexão
                    # Isso garante que o bot reconecte o mais rápido possível
                    if self.should_reconnect:
                        self.logger.info("🔄 Iniciando reconexão imediata...")
                        # Criar task de reconexão imediata (não bloquear o evento disconnect)
                        asyncio.create_task(self._immediate_reconnect())
                else:
                    # Falso positivo confirmado - não fazer nada
                    self.logger.debug("⚠️ Evento disconnect ignorado após verificação dupla - socket ainda conectado")
            finally:
                # Sempre liberar a flag após processar
                self._processing_disconnect = False
        
        @self.sio.event
        async def connect_error(data):
            import time
            current_time = time.time()
            
            # Prevenir múltiplos eventos de erro muito próximos (debounce de 5 segundos)
            if current_time - self._last_connect_error_time < 5:
                self.logger.debug(f"⚠️ Evento connect_error ignorado (muito próximo do anterior: {current_time - self._last_connect_error_time:.1f}s)")
                return
            
            # Ignorar erros muito próximos da conexão inicial (pode ser parte do processo de handshake)
            if self._connection_start_time > 0:
                time_since_connect = current_time - self._connection_start_time
                if time_since_connect < 10:  # Ignorar erros nos primeiros 10 segundos após conectar
                    self.logger.debug(f"⚠️ Evento connect_error ignorado (handshake inicial: {time_since_connect:.1f}s)")
                    return
            
            self._last_connect_error_time = current_time
            
            error_msg = str(data) if data else "Erro desconhecido"
            self.logger.error(f"❌ Erro de conexão Socket.IO: {error_msg} - O loop de reconexão tentará reconectar automaticamente")
            self.logger.info(f"📊 Estado após erro: connected={self.connected}, connecting={self.connecting}, reconnect_attempts={self.reconnect_attempts}")
            
            # NÃO marcar como desconectado aqui - o evento disconnect() será chamado se realmente desconectar
            # Isso evita desconexões falsas durante operações normais
            
            if self.on_error_callback:
                try:
                    await self.on_error_callback(data)
                except Exception as e:
                    self.logger.error(f"Erro no callback de erro: {e}")
        
        # Eventos de resposta específicos
        @self.sio.on('register_response')
        async def on_register_response(data):
            self.logger.debug(f"📨 Resposta de registro recebida: {data}")
            if 'register_response' in self.pending_responses:
                future = self.pending_responses.pop('register_response')
                if not future.done():
                    future.set_result(data)
            
            if self.on_message_callback:
                await self.on_message_callback({'event': 'register_response', 'data': data})
        
        @self.sio.on('synchronization_response')
        async def on_synchronization_response(data):
            self.logger.debug(f"📨 Resposta de sincronização recebida: {data}")
            if 'synchronization_response' in self.pending_responses:
                future = self.pending_responses.pop('synchronization_response')
                if not future.done():
                    future.set_result(data)
            
            if self.on_message_callback:
                await self.on_message_callback({'event': 'synchronization_response', 'data': data})
        
        @self.sio.on('gift_response')
        async def on_gift_response(data):
            self.logger.debug(f"📨 Resposta de presente recebida: {data}")
            if 'gift_response' in self.pending_responses:
                future = self.pending_responses.pop('gift_response')
                if not future.done():
                    future.set_result(data)
            
            if self.on_message_callback:
                await self.on_message_callback({'event': 'gift_response', 'data': data})

        @self.sio.on('update_gift_response')
        async def on_update_gift_response(data):
            self.logger.debug(f"📨 Resposta de atualização de gift recebida: {data}")
            if 'update_gift_response' in self.pending_responses:
                future = self.pending_responses.pop('update_gift_response')
                if not future.done():
                    future.set_result(data)
            
            if self.on_message_callback:
                await self.on_message_callback({'event': 'update_gift_response', 'data': data})

        @self.sio.on('delete_gift_response')
        async def on_delete_gift_response(data):
            self.logger.debug(f"📨 Resposta de deleção de gift recebida: {data}")
            if 'delete_gift_response' in self.pending_responses:
                future = self.pending_responses.pop('delete_gift_response')
                if not future.done():
                    future.set_result(data)
            
            if self.on_message_callback:
                await self.on_message_callback({'event': 'delete_gift_response', 'data': data})

        @self.sio.on('delete_all_gifts_response')
        async def on_delete_all_gifts_response(data):
            self.logger.debug(f"📨 Resposta de deleção em massa de gifts recebida: {data}")
            if 'delete_all_gifts_response' in self.pending_responses:
                future = self.pending_responses.pop('delete_all_gifts_response')
                if not future.done():
                    future.set_result(data)
            
            if self.on_message_callback:
                await self.on_message_callback({'event': 'delete_all_gifts_response', 'data': data})

        @self.sio.on('get_gifts_response')
        async def on_get_gifts_response(data):
            self.logger.debug(f"📨 Resposta de listagem de gifts recebida: {data}")
            if 'get_gifts_response' in self.pending_responses:
                future = self.pending_responses.pop('get_gifts_response')
                if not future.done():
                    future.set_result(data)
            
            if self.on_message_callback:
                await self.on_message_callback({'event': 'get_gifts_response', 'data': data})
        
        @self.sio.on('recover_response')
        async def on_recover_response(data):
            self.logger.debug(f"📨 Resposta de recuperação recebida: {data}")
            if 'recover_response' in self.pending_responses:
                future = self.pending_responses.pop('recover_response')
                if not future.done():
                    future.set_result(data)
            
            if self.on_message_callback:
                await self.on_message_callback({'event': 'recover_response', 'data': data})

        @self.sio.on('list_members_response')
        async def on_list_members_response(data):
            self.logger.info(f"📥 Resposta de listagem de membros recebida: {data}")
            if 'list_members_response' in self.pending_responses:
                future = self.pending_responses.pop('list_members_response')
                if not future.done():
                    future.set_result(data)
            
            if self.on_message_callback:
                await self.on_message_callback({'event': 'list_members_response', 'data': data})

        @self.sio.on('check_auth_count_response')
        async def on_check_auth_count_response(data):
            self.logger.info(f"📥 Resposta de contagem de membros autenticados recebida: {data}")
            if 'check_auth_count_response' in self.pending_responses:
                future = self.pending_responses.pop('check_auth_count_response')
                if not future.done():
                    future.set_result(data)
            
            if self.on_message_callback:
                await self.on_message_callback({'event': 'check_auth_count_response', 'data': data})

        @self.sio.on('recover_members_response')
        async def on_recover_members_response(data):
            self.logger.info(f"📥 Resposta de recuperação de membros recebida: {data}")
            if 'recover_members_response' in self.pending_responses:
                future = self.pending_responses.pop('recover_members_response')
                if not future.done():
                    future.set_result(data)
            
            if self.on_message_callback:
                await self.on_message_callback({'event': 'recover_members_response', 'data': data})

        @self.sio.on('check_user_verification_response')
        async def on_check_user_verification_response(data):
            self.logger.info(f"📥 Resposta de verificação de usuário recebida: {data}")
            if 'check_user_verification_response' in self.pending_responses:
                future = self.pending_responses.pop('check_user_verification_response')
                if not future.done():
                    future.set_result(data)
            
            if self.on_message_callback:
                await self.on_message_callback({'event': 'check_user_verification_response', 'data': data})

        @self.sio.on('redeem_gift')
        async def on_redeem_gift(data):
            self.logger.info(f"📥 Resgate de gift recebido: {data}")
            
            # Validar se o evento pertence a este bot
            if not self._validate_event_ownership(data):
                self.logger.info(f"⚠️ Evento redeem_gift ignorado - não pertence a este bot")
                return
            
            # Adicionar à queue para processamento não bloqueante
            try:
                self._event_queue.put_nowait({'event': 'redeem_gift', 'data': data})
            except asyncio.QueueFull:
                self.logger.warning("⚠️ Queue de eventos cheia, descartando redeem_gift")
            except Exception as e:
                self.logger.error(f"Erro ao adicionar redeem_gift à queue: {e}")
        
        @self.sio.on('recover_members')
        async def on_recover_members(data):
            self.logger.info(f"📥 Recuperação de membros recebida: {data}")
            
            # Validar se o evento pertence a este bot
            if not self._validate_event_ownership(data):
                self.logger.info(f"⚠️ Evento recover_members ignorado - não pertence a este bot")
                return
            
            # Adicionar à queue para processamento não bloqueante
            try:
                self._event_queue.put_nowait({'event': 'recover_members', 'data': data})
            except asyncio.QueueFull:
                self.logger.warning("⚠️ Queue de eventos cheia, descartando recover_members")
            except Exception as e:
                self.logger.error(f"Erro ao adicionar recover_members à queue: {e}")
        
        @self.sio.on('auth_log')
        async def on_auth_log(data):
            self.logger.info(f"📨 [DEBUG] AUTH LOG EVENT RECEIVED RAW: {data}")
            
            # Validar se o evento pertence a este bot
            if not self._validate_event_ownership(data):
                self.logger.info(f"⚠️ Evento auth_log ignorado - não pertence a este bot")
                return
            
            # Adicionar à queue para processamento não bloqueante
            try:
                self._event_queue.put_nowait({'event': 'auth_log', 'data': data})
            except asyncio.QueueFull:
                self.logger.warning("⚠️ Queue de eventos cheia, descartando auth_log")
            except Exception as e:
                self.logger.error(f"Erro ao adicionar auth_log à queue: {e}")
        
        @self.sio.on('remove_verified_role')
        async def on_remove_verified_role(data):
            self.logger.info(f"🗑️ Solicitação de remoção de cargo recebida: {data}")
            
            # Validar se o evento pertence a este bot
            if not self._validate_event_ownership(data):
                self.logger.info(f"⚠️ Evento remove_verified_role ignorado - não pertence a este bot")
                return
            
            # Adicionar à queue para processamento não bloqueante
            try:
                self._event_queue.put_nowait({'event': 'remove_verified_role', 'data': data})
            except asyncio.QueueFull:
                self.logger.warning("⚠️ Queue de eventos cheia, descartando remove_verified_role")
            except Exception as e:
                self.logger.error(f"Erro ao adicionar remove_verified_role à queue: {e}")
        
        # Handler para heartbeat_pong (resposta do servidor ao nosso ping)
        @self.sio.on('heartbeat_pong')
        async def on_heartbeat_pong(data):
            import time
            current_time = time.time()
            # Tratar resposta ao nosso ping
            try:
                ping_timestamp = data.get('timestamp', current_time) if isinstance(data, dict) else current_time
            except Exception:
                ping_timestamp = current_time
            
            latency = current_time - ping_timestamp
            
            # Atualizar estado de heartbeat
            self._last_pong_time = current_time
            self._pending_ping = False
            
            # Logs de latência (apenas quando relevante)
            if latency > 1.0:
                if latency > 5.0:
                    self.logger.warning(f"💓 Heartbeat pong (client) com latência muito alta: {latency:.2f}s")
                    # Se detectar perda de conexão, marcar estado para o loop de reconexão agir
                    if self.sio and hasattr(self.sio, 'connected') and not self.sio.connected:
                        self.logger.warning("💓 Conexão perdida detectada durante heartbeat (client)")
                        self.connected = False
                else:
                    self.logger.warning(f"💓 Heartbeat pong (client) com latência alta: {latency:.2f}s")
            else:
                self.logger.debug(f"💓 Heartbeat pong (client) recebido (latência: {latency:.2f}s)")
            
        # Handler para server_heartbeat_ping (ping enviado pelo servidor)
        @self.sio.on('server_heartbeat_ping')
        async def on_server_heartbeat_ping(data):
            import time
            # Responder imediatamente ao ping do servidor
            try:
                await self.sio.emit('server_heartbeat_pong', {
                    'timestamp': data.get('timestamp', time.time()),
                    'bot_timestamp': time.time(),
                    'bot_id': self.bot_discord_id if hasattr(self, 'bot_discord_id') else None
                })
                self.logger.debug("💓 Respondido ao ping do servidor")
            except Exception as e:
                self.logger.error(f"💓 Erro ao responder ping do servidor: {e}")
            current_time = time.time()
            ping_timestamp = data.get('timestamp', current_time)
            
            # Calcular latência (tempo de ida e volta)
            latency = current_time - ping_timestamp
            
            # Atualizar timestamp do último pong
            self._last_pong_time = current_time
            self._pending_ping = False
            
            # Log apenas se latência for alta (maior que 1 segundo) ou em debug
            if latency > 1.0:
                # Se latência muito alta (maior que 5 segundos), pode indicar problema de conexão
                if latency > 5.0:
                    self.logger.warning(f"💓 Heartbeat pong recebido com latência muito alta: {latency:.2f}s - pode indicar problemas de conexão")
                    # Verificar se conexão ainda está válida
                    if self.sio and hasattr(self.sio, 'connected'):
                        if not self.sio.connected:
                            self.logger.warning("💓 Conexão perdida detectada durante heartbeat")
                            self.connected = False
                else:
                    self.logger.warning(f"💓 Heartbeat pong recebido com latência alta: {latency:.2f}s")
            else:
                self.logger.debug(f"💓 Heartbeat pong recebido (latência: {latency:.2f}s)")

    def _validate_event_ownership(self, data: dict) -> bool:
        """Valida se o evento pertence a este bot baseado em client_id, bot_id ou guild_id"""
        try:
            from functions.database import database as db
            
            # Obter configuração do bot
            cloud_config = db.get_document("cloud_data") or {}
            bot_client_id = cloud_config.get("client_id")
            main_server_id = db.obter("config.json").get("bot", {}).get("server")
            
            # Verificar client_id (usado em auth_log)
            event_client_id = data.get("client_id") or data.get("clientId")
            if event_client_id and bot_client_id:
                if str(event_client_id) != str(bot_client_id):
                    return False
            
            # Verificar botId (usado em redeem_gift e recover_members)
            event_bot_id = data.get("botId") or data.get("bot_id")
            if event_bot_id and bot_client_id:
                if str(event_bot_id) != str(bot_client_id):
                    return False
            
            # Verificar guild_id (usado em vários eventos)
            event_guild_id = data.get("guild_id") or data.get("guildId")
            if event_guild_id and main_server_id:
                if str(event_guild_id) != str(main_server_id):
                    return False
            
            # Se passou por todas as validações ou não tinha campos para validar, aceitar
            return True
            
        except Exception as e:
            self.logger.error(f"Erro ao validar ownership do evento: {e}")
            # Em caso de erro, aceitar o evento para não bloquear funcionalidade
            return True

    async def _reconnect_loop(self):
        """Loop contínuo de reconexão que nunca para até conseguir conectar"""
        self.logger.info("🔄 Loop de reconexão iniciado - tentará reconectar continuamente até conseguir")
        
        # Aguardar um pouco antes de começar a tentar conectar (evitar conexões muito rápidas na inicialização)
        await asyncio.sleep(3)
        
        # Aguardar mais tempo antes de verificar inconsistências (evitar falsos positivos na inicialização)
        import time
        initial_wait_time = 15  # Aguardar 15 segundos antes de verificar inconsistências
        initial_start_time = time.time()
        
        while self.should_reconnect:
            try:
                # Verificar se já está conectado
                if self.connected and self.sio:
                    # Não verificar inconsistências muito cedo após inicialização
                    time_since_start = time.time() - initial_start_time
                    if time_since_start < initial_wait_time:
                        # Ainda no período inicial, apenas aguardar
                        await asyncio.sleep(5)
                        continue
                    
                    try:
                        # Verificar se o socket está realmente conectado
                        is_really_connected = False
                        if hasattr(self.sio, 'connected'):
                            is_really_connected = self.sio.connected
                        
                        # Verificar também o estado do engine IO
                        if is_really_connected and hasattr(self.sio, 'eio'):
                            try:
                                if hasattr(self.sio.eio, 'state'):
                                    if self.sio.eio.state != 'connected':
                                        is_really_connected = False
                            except Exception:
                                pass
                        
                        if is_really_connected:
                            # Está conectado e estável, aguardar mais tempo antes de verificar novamente
                            await asyncio.sleep(30)  # Verificar a cada 30s quando conectado (reduzido de 60s)
                            continue
                        else:
                            # Inconsistência: flag diz conectado mas socket não está
                            # Atualizar flag para refletir o estado real e forçar reconexão
                            self.logger.warning("⚠️ Inconsistência detectada: flag connected=True mas socket desconectado - corrigindo estado e reconectando")
                            self.connected = False
                            self.connecting = False
                            # Limpar socket antigo
                            if self.sio:
                                try:
                                    await self._safe_disconnect()
                                except Exception:
                                    pass
                    except Exception as e:
                        # Se houver erro ao verificar, assumir desconectado por segurança
                        self.logger.debug(f"Erro ao verificar conexão: {e} - assumindo desconectado")
                        self.connected = False
                        self.connecting = False
                        # Limpar socket antigo
                        if self.sio:
                            try:
                                await self._safe_disconnect()
                            except Exception:
                                pass
                
                # Se não está conectando e não está conectado, tentar conectar
                if not self.connecting and not self.connected:
                    self.logger.info(f"🔄 Tentando reconectar (tentativa #{self.reconnect_attempts + 1})...")
                    await self._connect()
                
                # Aguardar intervalo antes de tentar novamente
                # Usar intervalo menor para reconexão mais rápida
                sleep_time = 3  # Sempre 3 segundos entre tentativas quando desconectado
                if self.reconnect_attempts > 5:
                    sleep_time = 5  # Aumentar para 5s após 5 falhas
                if self.reconnect_attempts > 10:
                    sleep_time = 10  # Aumentar para 10s após 10 falhas
                await asyncio.sleep(sleep_time)
                
            except asyncio.CancelledError:
                self.logger.info("🛑 Loop de reconexão cancelado")
                break
            except Exception as e:
                self.logger.error(f"❌ Erro no loop de reconexão: {e}")
                import traceback
                traceback.print_exc()
                # Garantir que flags estão corretas mesmo em caso de erro
                self.connected = False
                self.connecting = False
                # Continuar tentando mesmo com erro, mas aguardar mais tempo
                await asyncio.sleep(max(self.reconnect_interval, 5))
    
    async def _connection_monitor(self):
        """Monitora a conexão periodicamente e corrige inconsistências"""
        self.logger.info("👁️ Monitor de conexão iniciado")
        
        # Aguardar um tempo antes de começar a monitorar (evitar falsos positivos na inicialização)
        await asyncio.sleep(30)
        
        while self.should_reconnect:
            try:
                await asyncio.sleep(120)  # Verificar a cada 120 segundos
                
                # Se não deveria reconectar, pular verificação
                if not self.should_reconnect:
                    break
                
                # Ignorar verificações muito próximas da conexão inicial (primeiros 60 segundos)
                import time
                if self._connection_start_time > 0:
                    time_since_connect = time.time() - self._connection_start_time
                    if time_since_connect < 60:
                        continue
                
                # Verificar se há inconsistência entre flag e estado real do socket
                if self.connected and self.sio:
                    try:
                        # Verificar se o socket está realmente conectado
                        is_really_connected = False
                        if hasattr(self.sio, 'connected'):
                            is_really_connected = self.sio.connected
                        
                        # Se flag diz conectado mas socket não está, corrigir inconsistência
                        if not is_really_connected:
                            self.logger.warning("⚠️ Monitor detectou inconsistência: flag connected=True mas socket desconectado - corrigindo")
                            self.connected = False
                            self.connecting = False
                    except Exception as e:
                        self.logger.debug(f"Erro ao verificar conexão no monitor: {e}")
                
            except asyncio.CancelledError:
                self.logger.info("🛑 Monitor de conexão cancelado")
                break
            except Exception as e:
                self.logger.error(f"❌ Erro no monitor de conexão: {e}")
                await asyncio.sleep(60)  # Aguardar mais tempo em caso de erro

    async def send_message(self, event: str, data: Dict[str, Any]) -> bool:
        """Envia mensagem via Socket.IO"""
        if not self.connected or not self.sio:
            self.logger.warning("⚠️ Socket.IO não conectado, não é possível enviar mensagem - O loop de reconexão tentará reconectar")
            return False
        
        try:
            # Verificar se realmente está conectado antes de enviar
            is_really_connected = False
            if hasattr(self.sio, 'connected'):
                is_really_connected = self.sio.connected
            
            if not is_really_connected:
                # Socket não está conectado, atualizar flag para refletir estado real
                self.logger.debug("⚠️ Socket.IO não está conectado ao tentar enviar mensagem - atualizando estado")
                self.connected = False
                self.connecting = False
                return False
            
            await self.sio.emit(event, data)
            self.logger.debug(f"📤 Mensagem enviada: {event}")
            return True
            
        except socketio.exceptions.BadNamespaceError:
            # Erro de namespace, não é problema de conexão
            self.logger.error(f"Erro de namespace ao enviar mensagem: {event}")
            return False
        except (socketio.exceptions.ConnectionError, OSError, ConnectionResetError) as e:
            # Erros de conexão - atualizar estado imediatamente
            self.logger.error(f"Erro de conexão ao enviar mensagem: {e}")
            self.connected = False
            self.connecting = False
            # O loop de reconexão vai tentar reconectar automaticamente
            return False
        except Exception as e:
            # Outros erros - não necessariamente problema de conexão
            self.logger.error(f"Erro ao enviar mensagem: {e}")
            return False

    async def register_bot(self, main_bot_id: str, token: str, client_secret: str, client_id: str) -> Dict[str, Any]:
        """Registra um bot via Socket.IO"""
        data = {
            "token": token,
            "clientSecret": client_secret,
            "clientId": client_id,
            "mainBotId": main_bot_id
        }
        
        if not await self.send_message("register", data):
            return {
                "success": False,
                "message": "Não foi possível enviar mensagem de registro"
            }
        
        return await self._wait_for_response("register_response", timeout=10.0)

    async def send_synchronization(self, bot_id: str, sync_data: Dict[str, Any]) -> Dict[str, Any]:
        """Envia dados de sincronização"""
        data = {
            "botId": bot_id,
            "data": sync_data
        }
        
        if not await self.send_message("synchronization", data):
            return {
                "success": False,
                "message": "Não foi possível enviar dados de sincronização"
            }
        
        return await self._wait_for_response("synchronization_response", timeout=10.0)

    async def send_gift(self, bot_id: str, gift_data: Dict[str, Any]) -> Dict[str, Any]:
        """Envia dados de presente"""
        data = {
            "botId": bot_id,
            "giftData": gift_data
        }
        
        if not await self.send_message("gift", data):
            return {
                "success": False,
                "message": "Não foi possível enviar dados de presente"
            }
        
        return await self._wait_for_response("gift_response", timeout=10.0)

    async def update_gift(self, update_data: Dict[str, Any]) -> Dict[str, Any]:
        """Atualiza um gift existente"""
        if not await self.send_message("update_gift", update_data):
            return {
                "success": False,
                "message": "Não foi possível enviar solicitação de atualização de gift"
            }
        
        return await self._wait_for_response("update_gift_response", timeout=10.0)

    async def delete_gift(self, delete_data: Dict[str, Any]) -> Dict[str, Any]:
        """Deleta um gift"""
        if not await self.send_message("delete_gift", delete_data):
            return {
                "success": False,
                "message": "Não foi possível enviar solicitação de deleção de gift"
            }
        
        return await self._wait_for_response("delete_gift_response", timeout=10.0)

    async def delete_all_gifts(self, delete_data: Dict[str, Any]) -> Dict[str, Any]:
        """Deleta todos os gifts"""
        if not await self.send_message("delete_all_gifts", delete_data):
            return {
                "success": False,
                "message": "Não foi possível enviar solicitação de deleção em massa de gifts"
            }
        
        return await self._wait_for_response("delete_all_gifts_response", timeout=30.0)

    async def get_gifts(self, bot_id: str) -> Dict[str, Any]:
        """Obtém lista de gifts de um bot"""
        data = {
            "botId": bot_id
        }
        
        if not await self.send_message("get_gifts", data):
            return {
                "success": False,
                "message": "Não foi possível enviar solicitação de listagem de gifts"
            }
        
        return await self._wait_for_response("get_gifts_response", timeout=10.0)

    async def recover_data(self, bot_id: str, recovery_data: Dict[str, Any] = None) -> Dict[str, Any]:
        """Recupera dados do servidor"""
        data = {
            "botId": bot_id,
            "recoveryData": recovery_data or {}
        }
        
        if not await self.send_message("recover", data):
            return {
                "success": False,
                "message": "Não foi possível enviar solicitação de recuperação"
            }
        
        return await self._wait_for_response("recover_response", timeout=10.0)

    async def list_members(self, bot_id: str) -> Dict[str, Any]:
        """Lista todos os membros do bot configurado"""
        data = {
            "botId": bot_id
        }
        
        self.logger.info(f"Enviando solicitação de listagem de membros para bot {bot_id}")
        
        if not await self.send_message("list_members", data):
            return {
                "success": False,
                "message": "Não foi possível enviar solicitação de listagem de membros"
            }
        
        self.logger.info(f"Aguardando resposta list_members_response para bot {bot_id}")
        return await self._wait_for_response("list_members_response", timeout=30.0)

    async def check_auth_count(self, bot_id: str) -> Dict[str, Any]:
        """Verifica quantos membros estão autenticados"""
        data = {
            "botId": bot_id
        }
        
        self.logger.info(f"Enviando solicitação de contagem de membros autenticados para bot {bot_id}")
        
        message_sent = await self.send_message("check_auth_count", data)
        
        if not message_sent:
            return {
                "success": False,
                "message": "Não foi possível enviar solicitação de contagem"
            }
        
        self.logger.info(f"Aguardando resposta check_auth_count_response para bot {bot_id}")
        response = await self._wait_for_response("check_auth_count_response", timeout=10.0)
        return response

    async def recover_members(self, bot_id: str, guild_id: str = None) -> Dict[str, Any]:
        """Recupera membros verificados do bot"""
        data = {
            "botId": bot_id,
            "guildId": guild_id
        }
        
        self.logger.info(f"Enviando solicitação de recuperação de membros para bot {bot_id}")
        
        if not await self.send_message("recover_members", data):
            return {
                "success": False,
                "message": "Não foi possível enviar solicitação de recuperação de membros"
            }
        
        self.logger.info(f"Aguardando resposta recover_members_response para bot {bot_id}")
        return await self._wait_for_response("recover_members_response", timeout=30.0)

    async def update_definitions(self, definitions: dict):
        """Envia as definições atualizadas para a API."""
        from functions.database import database as db
        
        self.logger.info(f"[UPDATE_DEFINITIONS] Iniciando envio de definições...")
        
        # Verificar conexão de forma mais rigorosa
        is_really_connected = False
        if self.is_connected() and self.sio:
            try:
                if hasattr(self.sio, 'connected'):
                    is_really_connected = self.sio.connected
                    # Verificar também o estado do engine IO
                    if is_really_connected and hasattr(self.sio, 'eio'):
                        try:
                            if hasattr(self.sio.eio, 'state'):
                                if self.sio.eio.state != 'connected':
                                    is_really_connected = False
                        except Exception:
                            pass
            except Exception:
                is_really_connected = False
        
        if not is_really_connected:
            self.logger.warning("[UPDATE_DEFINITIONS] WebSocket não está realmente conectado.")
            if self.connected:
                self.connected = False  # Corrigir estado inconsistente
            return False
        
        # Tentar carregar oauth_client_id se não estiver definido
        if not self.oauth_client_id:
            cloud_config = db.get_document("cloud_data") or {}
            self.oauth_client_id = cloud_config.get("client_id")
            self.logger.info(f"[UPDATE_DEFINITIONS] OAuth Client ID carregado: {self.oauth_client_id}")
        
        if not self.oauth_client_id:
            self.logger.error("[UPDATE_DEFINITIONS] oauth_client_id não configurado. Configure as credenciais primeiro.")
            return False

        try:
            main_server_id = db.obter("config.json").get("bot", {}).get("server")
        except Exception:
            main_server_id = None

        data = {
            "bot_id": self.oauth_client_id,
            "definitions": definitions,
            "main_server_id": main_server_id
        }
        
        self.logger.info(f"[UPDATE_DEFINITIONS] Enviando definições para bot_id={self.oauth_client_id}, definições={list(definitions.keys())}")
        
        try:
            # Verificar novamente antes de enviar (double-check)
            if not self.sio or not hasattr(self.sio, 'connected') or not self.sio.connected:
                self.logger.warning("[UPDATE_DEFINITIONS] Socket desconectou durante preparação do envio")
                self.connected = False
                return False
            
            # Usar emit diretamente
            await self.sio.emit("update_definitions", data)
            self.logger.info(f"[UPDATE_DEFINITIONS] ✅ Definições enviadas com sucesso para a API (bot_id: {self.oauth_client_id})")
            return True
        except Exception as e:
            self.logger.error(f"[UPDATE_DEFINITIONS] ❌ Erro ao enviar definições: {e}")
            import traceback
            traceback.print_exc()
            # Se falhou ao enviar, pode ser que desconectou
            self.connected = False
            return False

    async def check_user_verification(self, bot_id: str, user_id: int):
        """Verifica se um usuário está verificado na API."""
        if not self.is_connected():
            return {"success": False, "message": "WebSocket não conectado."}

        data = {
            "botId": bot_id,
            "userId": str(user_id)
        }
        sent = await self.send_message("check_user_verification", data)
        if not sent:
            return {"success": False, "message": "Não foi possível enviar solicitação de verificação de usuário"}
        return await self._wait_for_response("check_user_verification_response", timeout=10.0)
        
    def _generate_request_id(self):
        """Gera um ID de requisição único."""
        return str(uuid.uuid4())

    async def _wait_for_response(self, request_id: str, timeout: float = 10.0) -> Dict[str, Any]:
        """Aguarda resposta específica do servidor"""
        try:
            # Criar future para aguardar resposta
            future = asyncio.Future()
            self.pending_responses[request_id] = future
            
            self.logger.info(f"Aguardando evento '{request_id}' com timeout de {timeout}s")
            self.logger.info(f"Respostas pendentes: {list(self.pending_responses.keys())}")
            
            # Aguardar resposta com timeout
            response = await asyncio.wait_for(future, timeout=timeout)
            
            self.logger.info(f"Resposta recebida para '{request_id}': {response}")
            
            # A resposta já vem no formato correto da API
            return response
            
        except asyncio.TimeoutError:
            # Remover future pendente se timeout
            self.pending_responses.pop(request_id, None)
            return {
                "success": False,
                "message": f"Timeout ao aguardar resposta para {request_id}"
            }
        except Exception as e:
            # Remover future pendente em caso de erro
            self.pending_responses.pop(request_id, None)
            return {
                "success": False,
                "message": f"Erro ao aguardar resposta: {str(e)}"
            }

    def is_connected(self) -> bool:
        """Verifica se está conectado"""
        return self.connected
    
    async def resend_bot_connected(self):
        """Força reenvio do evento bot_connected (útil quando bot fica pronto após conectar)"""
        if not self.connected or not self.sio:
            return False
        
        try:
            # Atualizar bot_discord_id se necessário
            if hasattr(self, 'bot') and self.bot and hasattr(self.bot, 'user') and self.bot.user:
                self.bot_discord_id = str(self.bot.user.id)
            
            if not self.bot_discord_id:
                return False
            
            # Obter lista de servidores
            guilds = []
            if hasattr(self.bot, 'guilds') and self.bot.guilds:
                guilds = [str(g.id) for g in self.bot.guilds]
            
            # Preparar dados
            registration_data = {
                'bot_id': self.bot_discord_id,
                'unique_id': self.bot_unique_id,
                'server_id': self.bot_server_id,
                'oauth_client_id': self.oauth_client_id,
                'guild_count': len(guilds),
                'guilds': guilds
            }
            
            # Emitir
            await self.sio.emit('bot_connected', registration_data)
            self.logger.info(f"✅ Registro atualizado na API")
            return True
            
        except Exception as e:
            self.logger.error(f"❌ Erro ao reenviar bot_connected: {e}")
            return False

    async def _immediate_reconnect(self):
        """Reconexão imediata após desconexão detectada"""
        try:
            # Aguardar 2 segundos antes de reconectar (evitar reconexão muito rápida)
            await asyncio.sleep(2)
            
            # Verificar se ainda deve reconectar e não está conectado
            if self.should_reconnect and not self.connected and not self.connecting:
                self.logger.info("🔄 Executando reconexão imediata após desconexão detectada...")
                # Resetar flags para garantir estado limpo
                self.connected = False
                self.connecting = False
                # Limpar socket antigo se existir
                if self.sio:
                    try:
                        await self._safe_disconnect()
                    except Exception:
                        pass
                # Tentar conectar
                await self._connect()
            else:
                self.logger.debug(f"🔄 Reconexão imediata pulada - should_reconnect={self.should_reconnect}, connected={self.connected}, connecting={self.connecting}")
        except Exception as e:
            self.logger.error(f"Erro na reconexão imediata: {e}")
            import traceback
            traceback.print_exc()
            # Garantir que flags estão corretas mesmo em caso de erro
            self.connected = False
            self.connecting = False
    
    def _start_heartbeat(self):
        """Inicia o sistema de heartbeat (ping/pong) MELHORADO"""
        if self.heartbeat_task and not self.heartbeat_task.done():
            return  # Já está rodando
        
        async def heartbeat_loop():
            import time
            self.logger.info("💓 Sistema de heartbeat iniciado (intervalo: 20s, timeout: 5min)")
            
            # Enviar primeiro ping após 5 segundos da conexão
            await asyncio.sleep(5)
            
            ping_count = 0
            consecutive_failures = 0
            MAX_CONSECUTIVE_FAILURES = 3  # Permitir até 3 falhas consecutivas antes de reconectar
            
            while self.should_reconnect and self.connected:
                try:
                    # Verificar se ainda está conectado antes de enviar ping
                    if not self.connected or not self.sio:
                        self.logger.debug("💓 Não conectado, parando heartbeat")
                        break
                    
                    if not hasattr(self.sio, 'connected') or not self.sio.connected:
                        self.logger.warning("💓 Socket desconectado durante heartbeat, forçando desconexão segura e reconexão")
                        self.connected = False
                        self.connecting = False
                        # Forçar desconexão segura para limpar estado
                        if self.sio:
                            try:
                                await self._safe_disconnect()
                            except Exception:
                                pass
                        # Criar task de reconexão imediata
                        if self.should_reconnect:
                            asyncio.create_task(self._immediate_reconnect())
                        break
                    
                    current_time = time.time()
                    
                    # Verificar timeout do último pong (reduzido para 90 segundos)
                    if self._last_pong_time > 0:
                        time_since_last_pong = current_time - self._last_pong_time
                        if time_since_last_pong > self.heartbeat_timeout:
                            self.logger.warning(f"💓 ⚠️ Timeout de heartbeat detectado ({time_since_last_pong:.1f}s sem pong)")
                            consecutive_failures += 1
                            if consecutive_failures >= MAX_CONSECUTIVE_FAILURES:
                                self.logger.error(f"💓 ❌ {MAX_CONSECUTIVE_FAILURES} falhas consecutivas, forçando reconexão...")
                                self.connected = False
                                self.connecting = False
                                if self.sio:
                                    await self._safe_disconnect()
                                # Criar task de reconexão imediata
                                if self.should_reconnect:
                                    asyncio.create_task(self._immediate_reconnect())
                                break
                            else:
                                self.logger.warning(f"💓 Falha {consecutive_failures}/{MAX_CONSECUTIVE_FAILURES}, continuando...")
                    else:
                        # Se nunca recebeu pong e já passou tempo suficiente, considerar problema
                        if self._connection_start_time > 0:
                            time_since_connect = current_time - self._connection_start_time
                            if time_since_connect > 60:  # 1 minuto sem pong após conectar
                                consecutive_failures += 1
                                if consecutive_failures >= MAX_CONSECUTIVE_FAILURES:
                                    self.logger.error(f"💓 ❌ Nunca recebeu pong após {time_since_connect:.1f}s, forçando reconexão...")
                                    self.connected = False
                                    self.connecting = False
                                    if self.sio:
                                        await self._safe_disconnect()
                                    if self.should_reconnect:
                                        asyncio.create_task(self._immediate_reconnect())
                                    break
                    
                    # Enviar ping periodicamente
                    try:
                        ping_data = {
                            'timestamp': current_time,
                            'bot_id': self.bot_discord_id if hasattr(self, 'bot_discord_id') else None
                        }
                        await self.sio.emit('heartbeat_ping', ping_data)
                        self._pending_ping = True
                        ping_count += 1
                        
                        # Log apenas a cada 5 pings para não poluir
                        if ping_count % 5 == 0:
                            self.logger.info(f"💓 Heartbeat ativo ({ping_count} pings enviados)")
                        else:
                            self.logger.debug("💓 Heartbeat ping enviado")
                        
                        # Reset de falhas consecutivas se ping foi enviado com sucesso
                        consecutive_failures = 0
                        
                    except Exception as e:
                        self.logger.error(f"💓 Erro ao enviar heartbeat ping: {e}")
                        consecutive_failures += 1
                        
                        # Se falhar muitas vezes, desconectar
                        if consecutive_failures >= MAX_CONSECUTIVE_FAILURES:
                            self.logger.error(f"💓 ❌ {MAX_CONSECUTIVE_FAILURES} falhas ao enviar ping, forçando reconexão...")
                            self.connected = False
                            self.connecting = False
                            # Forçar desconexão segura
                            if self.sio:
                                try:
                                    await self._safe_disconnect()
                                except Exception:
                                    pass
                            # Criar task de reconexão imediata
                            if self.should_reconnect:
                                asyncio.create_task(self._immediate_reconnect())
                            break
                    
                    # Aguardar intervalo antes do próximo ping
                    await asyncio.sleep(self.heartbeat_interval)
                    
                except asyncio.CancelledError:
                    self.logger.info("💓 Sistema de heartbeat cancelado")
                    break
                except Exception as e:
                    self.logger.error(f"💓 Erro no loop de heartbeat: {e}")
                    consecutive_failures += 1
                    if consecutive_failures >= MAX_CONSECUTIVE_FAILURES:
                        self.logger.error(f"💓 ❌ Muitos erros consecutivos, forçando reconexão")
                        self.connected = False
                        self.connecting = False
                        # Forçar desconexão segura
                        if self.sio:
                            try:
                                await self._safe_disconnect()
                            except Exception:
                                pass
                        # Criar task de reconexão imediata
                        if self.should_reconnect:
                            asyncio.create_task(self._immediate_reconnect())
                        break
                    await asyncio.sleep(5)  # Aguardar um pouco antes de continuar
            
            self.logger.info(f"💓 Sistema de heartbeat parado (total de {ping_count} pings enviados)")
        
        self.heartbeat_task = asyncio.create_task(heartbeat_loop())
    
    async def _process_event_queue(self):
        """Processa eventos da queue de forma não bloqueante com timeout"""
        self.logger.info("📨 Processador de eventos iniciado")
        
        while self.should_reconnect:
            try:
                # Aguardar evento da queue com timeout
                try:
                    message_data = await asyncio.wait_for(
                        self._event_queue.get(),
                        timeout=1.0
                    )
                except asyncio.TimeoutError:
                    continue  # Timeout normal, continuar loop
                
                # Processar evento com timeout para não bloquear
                try:
                    await asyncio.wait_for(
                        self._handle_event_message(message_data),
                        timeout=30.0  # Timeout de 30 segundos por evento
                    )
                except asyncio.TimeoutError:
                    self.logger.error(f"⚠️ Timeout ao processar evento: {message_data.get('event', 'unknown')}")
                except Exception as e:
                    self.logger.error(f"❌ Erro ao processar evento: {e}")
                    import traceback
                    traceback.print_exc()
                
            except asyncio.CancelledError:
                self.logger.info("📨 Processador de eventos cancelado")
                break
            except Exception as e:
                self.logger.error(f"❌ Erro no processador de eventos: {e}")
                await asyncio.sleep(1)  # Aguardar antes de continuar
    
    async def _handle_event_message(self, message_data: dict):
        """Processa uma mensagem de evento específica"""
        if not self.on_message_callback:
            return
        
        event = message_data.get('event')
        data = message_data.get('data', {})
        
        # Processar eventos com tratamento de erro individual e timeout
        try:
            await asyncio.wait_for(
                self.on_message_callback({'event': event, 'data': data}),
                timeout=30.0  # Timeout de 30 segundos por evento
            )
        except asyncio.TimeoutError:
            self.logger.error(f"❌ Timeout ao processar evento {event} (30s)")
        except Exception as e:
            self.logger.error(f"❌ Erro no callback de mensagem para evento {event}: {e}")
            import traceback
            traceback.print_exc()
            # Não propagar erro para não bloquear outros eventos
    
    def get_connection_info(self) -> Dict[str, Any]:
        """Retorna informações da conexão"""
        import time
        heartbeat_status = "ativo" if (self.heartbeat_task and not self.heartbeat_task.done()) else "inativo"
        time_since_last_pong = time.time() - self._last_pong_time if self._last_pong_time > 0 else 0
        queue_size = self._event_queue.qsize() if hasattr(self, '_event_queue') else 0
        
        return {
            "connected": self.connected,
            "connecting": self.connecting,
            "server_url": self.server_url,
            "should_reconnect": self.should_reconnect,
            "event_queue_size": queue_size,
            "heartbeat": {
                "status": heartbeat_status,
                "interval": self.heartbeat_interval,
                "timeout": self.heartbeat_timeout,
                "last_pong": time_since_last_pong,
                "pending_ping": self._pending_ping
            }
        }